
const express = require('express');
const app = express();
const port = 3000;

// Datos simulados de los activos
const activos = [
    { id: "1234567890", nombre: "Computadora", descripcion: "PC de oficina", fecha_adquisicion: "2024-01-15", ubicacion: "Oficina A", valor: 5000 },
    { id: "0987654321", nombre: "Silla", descripcion: "Silla ergonómica", fecha_adquisicion: "2023-11-05", ubicacion: "Oficina B", valor: 150 },
];

// Configurar Express para servir archivos estáticos
app.use(express.static('frontend'));

// Endpoint para obtener detalles del activo
app.get('/activo/:id', (req, res) => {
    const activoId = req.params.id;
    const activo = activos.find(a => a.id === activoId);
    
    if (activo) {
        res.json(activo);
    } else {
        res.status(404).json({ error: "Activo no encontrado" });
    }
});

// Iniciar el servidor
app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});
