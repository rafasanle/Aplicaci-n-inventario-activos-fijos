
// Generación del código de barras
const form = document.getElementById('form-activo');
const barcodeContainer = document.getElementById('barcode');

form.addEventListener('submit', function(e) {
    e.preventDefault();
    const activoId = document.getElementById('activo-id').value;

    // Generar código de barras
    if (activoId) {
        JsBarcode("#barcode", activoId, {
            format: "CODE128",
            width: 2,
            height: 40,
            displayValue: true
        });
    } else {
        alert("Por favor, ingrese un ID de activo.");
    }
});

// Iniciar escaneo de código de barras
const startScanButton = document.getElementById('start-scan');
const scannerContainer = document.getElementById('scanner-container');

startScanButton.addEventListener('click', function() {
    // Inicializar Quagga para el escaneo en vivo
    Quagga.init({
        inputStream: {
            name: "Live",
            type: "LiveStream",
            target: scannerContainer // Contenedor del escáner
        },
        decoder: {
            readers: ["code_128_reader", "ean_reader"]
        }
    }, function(err) {
        if (err) {
            console.log(err);
            return;
        }
        Quagga.start(); // Iniciar el escaneo
    });

    Quagga.onDetected(function(result) {
        alert("Código detectado: " + result.codeResult.code);
        // Redirigir al detalle del activo
        window.location.href = `/activo/${result.codeResult.code}`;
    });
});
